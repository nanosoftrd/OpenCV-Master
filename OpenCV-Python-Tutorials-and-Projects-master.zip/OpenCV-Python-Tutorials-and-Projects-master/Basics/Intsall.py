#In this tutorial we learn how to install PYTHON and PYCHARM. Later we install the OPENCV plugin and test it out. 

# Links 
# https://python.org/downloads/
# https://www.jetbrains.com/pycharm/download/#section=windows


#Install Python first and then install the Pycharm Community Edition
#To install opencv go to pycharm then 
# File - Settings - Project - Project Interpreter - "+" (add button) - Search for opencv-python and click on Install Package
# Then search for numpy and install 
# Create a new python file and run the code below to test the installation

import cv2
import numpy
print("This is a Text)
