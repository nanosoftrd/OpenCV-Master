Requires Installation 
https://tesseract-ocr.github.io/tessdoc/Home.html
